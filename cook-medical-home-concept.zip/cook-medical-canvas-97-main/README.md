
# Cook Medical Concept - Medical Device Innovation Platform

## About This Project

This is a concept application for Cook Medical, showcasing innovative approaches to medical device information systems. Cook Medical is a family-owned medical device company that works with physicians to develop devices that are less invasive for patients.

## Project Overview

This platform demonstrates modern web technologies applied to medical device information presentation, focusing on:

- Minimally invasive procedure solutions
- Medical device catalog and information systems
- Physician-focused user experience design
- Responsive design for healthcare professionals

## Technologies Used

This project is built with modern web technologies:

- **React** - Component-based user interface
- **TypeScript** - Type-safe development
- **Vite** - Fast build tool and development server
- **Tailwind CSS** - Utility-first CSS framework
- **shadcn/ui** - Modern UI component library
- **React Query** - Data fetching and state management
- **React Router** - Client-side routing

## Development Setup

### Prerequisites

- Node.js (version 16 or higher)
- npm or yarn package manager

### Getting Started

1. **Clone the repository**
   ```sh
   git clone <repository-url>
   cd <project-directory>
   ```

2. **Install dependencies**
   ```sh
   npm install
   ```

3. **Start the development server**
   ```sh
   npm run dev
   ```

4. **Open your browser**
   Navigate to `http://localhost:5173` to view the application

### Available Scripts

- `npm run dev` - Start development server with hot reload
- `npm run build` - Build the application for production
- `npm run preview` - Preview the production build locally
- `npm run lint` - Run ESLint for code quality checks

## Project Structure

```
src/
├── components/          # Reusable UI components
│   ├── layout/         # Layout-specific components
│   └── ui/             # Base UI components
├── pages/              # Application pages
├── hooks/              # Custom React hooks
├── lib/                # Utility functions
└── styles/             # Global styles and Tailwind config
```

## Design System

This project implements Cook Medical's design principles:

- **Typography**: Manrope, DM Sans, and Sora font families
- **Color Palette**: Medical-focused color scheme
- **Components**: Healthcare-appropriate UI patterns
- **Accessibility**: WCAG compliant design standards

## Contributing

When contributing to this concept project:

1. Follow the existing code style and patterns
2. Ensure all components are properly typed with TypeScript
3. Test your changes across different screen sizes
4. Maintain focus on medical device industry standards
5. Keep accessibility standards in mind

## Medical Device Focus

This concept application is designed specifically for the medical device industry, with particular attention to:

- Healthcare professional workflow integration
- Medical device specification presentation
- Regulatory compliance considerations
- Patient safety information display

## License

This is a concept project for Cook Medical evaluation purposes.

---

*Cook Medical - Committed to improving the quality of life by providing physicians with the medical devices they need to provide the best patient care possible.*
