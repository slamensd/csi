
import React from 'react';
import { Badge } from './badge';

interface CategoryChipsProps {
  selectedCategory: string;
  onCategorySelect: (category: string) => void;
}

const CategoryChips = ({ selectedCategory, onCategorySelect }: CategoryChipsProps) => {
  const categories: { id: string; label: string; icon: string }[] = [];

  return (
    <div className="flex flex-wrap gap-2 sm:gap-3 justify-center">
      {categories.map((category) => (
        <Badge
          key={category.id}
          variant={selectedCategory === category.id ? "default" : "outline"}
          className={`cursor-pointer transition-all duration-200 px-3 py-2 text-sm sm:text-base font-dm-sans ${
            selectedCategory === category.id
              ? 'bg-cook-red text-white hover:bg-cook-dark-red'
              : 'bg-white/80 text-graphite-gray hover:bg-white border-surgical-steel hover:border-cook-red'
          }`}
          onClick={() => onCategorySelect(category.id)}
        >
          <span className="mr-1 sm:mr-2">{category.icon}</span>
          {category.label}
        </Badge>
      ))}
    </div>
  );
};

export default CategoryChips;
