import React from 'react';
import { Building2, Search } from 'lucide-react';

interface DivisionsComponentProps {
  onSearchSelect: (search: string) => void;
}

const DivisionsComponent = ({ onSearchSelect }: DivisionsComponentProps) => {
  const divisions = {
    vascular: [
      'Aortic Intervention',
      'Interventional Radiology',
      'Lead Management',
      'Peripheral Intervention'
    ],
    medSurg: [
      'Critical Care',
      'Endoscopy',
      'Otolaryngology',
      'Reproductive Health',
      'Surgery',
      'Urology'
    ]
  };

  return (
    <div className="w-full">
      <div className="bg-white/90 backdrop-blur-sm rounded-lg p-4 sm:p-6 shadow-lg border border-white/20">
        <div className="flex items-center space-x-2 mb-4">
          <Building2 className="h-5 w-5 text-cook-red" />
          <h3 className="text-lg font-manrope font-semibold text-graphite-gray">Our Divisions</h3>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Vascular Division */}
          <div>
            <h4 className="text-base font-manrope font-semibold text-cook-red mb-3">Vascular</h4>
            <div className="space-y-2">
              {divisions.vascular.map((item, index) => (
                <button
                  key={index}
                  onClick={() => onSearchSelect(item)}
                  className="flex items-center space-x-2 p-2 sm:p-3 bg-porcelain-gray hover:bg-white rounded-lg transition-colors duration-200 text-left group w-full"
                >
                  <Search className="h-4 w-4 text-soft-charcoal group-hover:text-cook-red transition-colors" />
                  <span className="text-sm sm:text-base font-dm-sans text-graphite-gray group-hover:text-cook-red transition-colors">
                    {item}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* MedSurg Division */}
          <div>
            <h4 className="text-base font-manrope font-semibold text-cook-red mb-3">MedSurg</h4>
            <div className="space-y-2">
              {divisions.medSurg.map((item, index) => (
                <button
                  key={index}
                  onClick={() => onSearchSelect(item)}
                  className="flex items-center space-x-2 p-2 sm:p-3 bg-porcelain-gray hover:bg-white rounded-lg transition-colors duration-200 text-left group w-full"
                >
                  <Search className="h-4 w-4 text-soft-charcoal group-hover:text-cook-red transition-colors" />
                  <span className="text-sm sm:text-base font-dm-sans text-graphite-gray group-hover:text-cook-red transition-colors">
                    {item}
                  </span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DivisionsComponent;
