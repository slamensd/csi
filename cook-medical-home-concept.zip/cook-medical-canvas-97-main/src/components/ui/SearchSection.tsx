
import React, { useState, useEffect, useRef } from 'react';
import { Search } from 'lucide-react';
import { Button } from './button';
import { Input } from './input';
import CategoryChips from './CategoryChips';
import DivisionsComponent from './DivisionsComponent';
import DivisionCards from './DivisionCards';

const SearchSection = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(-1);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [isDivisionSearch, setIsDivisionSearch] = useState(false);
  const [animationState, setAnimationState] = useState<'idle' | 'sliding-out' | 'sliding-in' | 'showing-cards'>('idle');
  const searchRef = useRef<HTMLDivElement>(null);

  // Division terms for detection
  const divisionTerms = [
    'Aortic Intervention',
    'Interventional Radiology',
    'Lead Management',
    'Peripheral Intervention',
    'Critical Care',
    'Endoscopy',
    'Otolaryngology',
    'Reproductive Health',
    'Surgery',
    'Urology'
  ];

  // Enhanced mock suggestions data with categories
  const mockSuggestions = ['Cook Medical products', 'Cook Medical instructions for use', 'Cook Medical training courses', 'Cook Medical customer portal', 'Cook Medical IFU finder', 'Cook Medical Vista education', 'Cook Medical device documentation', 'Cook Medical surgical instruments', 'Cook Medical minimally invasive devices', 'Cook Medical medical devices', 'Cook Medical endoscopy products', 'Cook Medical urology products', 'Cook Medical vascular products', 'Cook Medical women\'s health', 'Cook Medical interventional products'];

  // Check if search term is a division
  const isDivisionTerm = (term: string) => {
    return divisionTerms.some(division => 
      division.toLowerCase() === term.toLowerCase()
    );
  };

  useEffect(() => {
    if (searchTerm.length > 2) {
      const filtered = mockSuggestions.filter(suggestion => suggestion.toLowerCase().includes(searchTerm.toLowerCase())).slice(0, 5);
      setSuggestions(filtered);
      setShowSuggestions(true);
      setSelectedIndex(-1);
    } else {
      setShowSuggestions(false);
      setSuggestions([]);
    }
  }, [searchTerm]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setShowSuggestions(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSearch = (term?: string) => {
    const searchQuery = term || searchTerm;
    console.log('Searching for:', searchQuery, 'in category:', selectedCategory);
    setShowSuggestions(false);

    // Check if this is a division search
    if (isDivisionTerm(searchQuery)) {
      setIsDivisionSearch(true);
      
      // Start slide animation sequence
      setAnimationState('sliding-out');
      
      // After slide-out completes, start slide-in
      setTimeout(() => {
        setAnimationState('sliding-in');
      }, 500);
      
      // After slide-in completes, set to showing cards
      setTimeout(() => {
        setAnimationState('showing-cards');
      }, 1000);
    } else {
      // Regular search behavior - reset to idle state
      setIsDivisionSearch(false);
      setAnimationState('idle');
      console.log('Regular search for:', searchQuery);
    }
  };

  const handleGoToResults = () => {
    console.log('Going to search results for division search');
    
    // Start reverse animation sequence
    setAnimationState('sliding-out');
    
    // After slide-out completes, reset to idle
    setTimeout(() => {
      setIsDivisionSearch(false);
      setAnimationState('idle');
    }, 500);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      if (selectedIndex >= 0 && suggestions[selectedIndex]) {
        handleSearch(suggestions[selectedIndex]);
        setSearchTerm(suggestions[selectedIndex]);
      } else {
        handleSearch();
      }
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSelectedIndex(prev => prev < suggestions.length - 1 ? prev + 1 : prev);
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedIndex(prev => prev > 0 ? prev - 1 : -1);
    } else if (e.key === 'Escape') {
      setShowSuggestions(false);
      setSelectedIndex(-1);
    }
  };

  const handleSuggestionClick = (suggestion: string) => {
    setSearchTerm(suggestion);
    handleSearch(suggestion);
  };

  const handleCategorySelect = (category: string) => {
    setSelectedCategory(category);
    console.log('Selected category:', category);
  };

  const handlePopularSearchSelect = (search: string) => {
    setSearchTerm(search);
    handleSearch(search);
  };

  // Get transform classes based on animation state
  const getDivisionsComponentTransform = () => {
    switch (animationState) {
      case 'sliding-out':
        return 'transform -translate-x-full opacity-0';
      case 'sliding-in':
      case 'showing-cards':
        return 'transform -translate-x-full opacity-0';
      default:
        return 'transform translate-x-0 opacity-100';
    }
  };

  const getDivisionCardsTransform = () => {
    switch (animationState) {
      case 'idle':
        return 'transform translate-x-full opacity-0';
      case 'sliding-out':
        return 'transform translate-x-full opacity-0';
      case 'sliding-in':
        return 'transform translate-x-0 opacity-100';
      case 'showing-cards':
        return 'transform translate-x-0 opacity-100';
      default:
        return 'transform translate-x-full opacity-0';
    }
  };

  return (
    <section className="min-h-screen bg-cook-red flex items-center">
      <div className="container mx-auto px-4 sm:px-6 lg:px-4 w-full">
        <div className="max-w-6xl mx-auto space-y-6 sm:space-y-8">
          {/* Main Search Bar */}
          <div ref={searchRef}>
            <div className="bg-medical-white border border-surgical-steel rounded-full p-2 sm:p-4 shadow-lg relative">
              <div className="flex items-center space-x-2 sm:space-x-4">
                <div className="flex-1 relative">
                  <Input type="text" placeholder="Search for products, documents, pages, or articles" value={searchTerm} onChange={e => setSearchTerm(e.target.value)} onKeyDown={handleKeyPress} className="w-full pl-4 sm:pl-8 pr-4 sm:pr-8 py-3 text-lg sm:text-2xl text-graphite-gray placeholder:text-soft-charcoal border-0 bg-transparent focus:ring-0 focus:outline-none focus:border-transparent focus-visible:ring-0 focus-visible:ring-transparent focus-visible:ring-offset-0 font-dm-sans sm:py-0" />
                </div>
                <Button onClick={() => handleSearch()} className="bg-graphite-gray hover:bg-black text-medical-white px-4 sm:px-10 py-3 sm:py-6 rounded-full font-manrope font-semibold transition-colors duration-200 flex items-center space-x-1 sm:space-x-2 text-sm sm:text-xl">
                  <Search className="h-5 w-5 sm:h-7 sm:w-7" />
                  <span className="hidden sm:inline">Search</span>
                </Button>
              </div>

              {/* Enhanced Suggestions */}
              {showSuggestions && suggestions.length > 0 && <div className="absolute top-full left-2 right-2 sm:left-4 sm:right-4 mt-2 bg-white rounded-lg shadow-xl border border-gray-200 overflow-hidden z-50">
                  {suggestions.map((suggestion, index) => <div key={index} onClick={() => handleSuggestionClick(suggestion)} className={`px-4 sm:px-6 py-3 sm:py-4 cursor-pointer text-graphite-gray hover:bg-porcelain-gray transition-colors duration-150 ${index === selectedIndex ? 'bg-porcelain-gray' : ''}`}>
                      <div className="flex items-center space-x-2 sm:space-x-3">
                        <Search className="h-4 w-4 sm:h-5 sm:w-5 text-soft-charcoal" />
                        <span className="font-dm-sans text-sm sm:text-lg">{suggestion}</span>
                        <span className="ml-auto text-xs text-soft-charcoal bg-porcelain-gray px-2 py-1 rounded">
                          {suggestion.includes('training') ? 'Training' : suggestion.includes('IFU') || suggestion.includes('instructions') ? 'Documentation' : suggestion.includes('urology') ? 'Urology' : suggestion.includes('vascular') ? 'Vascular' : suggestion.includes('endoscopy') ? 'Endoscopy' : 'Product'}
                        </span>
                      </div>
                    </div>)}
                </div>}
            </div>
          </div>

          {/* Category Filter Chips */}
          <CategoryChips selectedCategory={selectedCategory} onCategorySelect={handleCategorySelect} />

          {/* Content Container with Slide Animation */}
          <div className="relative overflow-hidden">
            {/* Divisions Component */}
            <div className={`max-w-4xl mx-auto transition-all duration-500 ease-in-out ${getDivisionsComponentTransform()}`}>
              <DivisionsComponent onSearchSelect={handlePopularSearchSelect} />
            </div>

            {/* Division Cards */}
            <div className={`max-w-5xl mx-auto absolute top-0 left-0 right-0 transition-all duration-500 ease-in-out ${getDivisionCardsTransform()}`}>
              <DivisionCards />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default SearchSection;
