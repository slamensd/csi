
import React from 'react';
import StatisticsCard from './StatisticsCard';

const HeroSection = () => {
  return (
    <section className="relative bg-gradient-to-br from-porcelain-gray to-medical-white min-h-screen flex items-center overflow-hidden">
      {/* Background Video - responsive handling */}
      <video
        autoPlay
        muted
        loop
        playsInline
        className="absolute inset-0 w-full h-full object-cover z-0"
        style={{ objectPosition: 'center top' }}
      >
        <source src="https://meetnippy.mypinata.cloud/ipfs/bafybeic7kg4e3zc4k3s3d4qo3ir3ng5lasuhyd76ueaoxhmfcx3h6bchoi" type="video/mp4" />
      </video>
      
      {/* Overlay for better text readability */}
      <div className="absolute inset-0 bg-black bg-opacity-30 z-10"></div>
      
      {/* Main Content - Positioned in Bottom Left */}
      <div className="absolute bottom-8 left-4 sm:bottom-12 sm:left-6 lg:bottom-16 lg:left-8 z-20 max-w-2xl">
        <div className="text-left">
          <h1 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-manrope font-bold text-medical-white mb-4 sm:mb-6 leading-tight drop-shadow-lg">
            Precision That Heals.
            <span className="text-cook-red block mt-1 sm:mt-2">Simplicity That Empowers.</span>
          </h1>
          <p className="text-base sm:text-lg font-dm-sans text-medical-white mb-6 sm:mb-8 leading-relaxed drop-shadow-md">
            Every patient wants to heal. Every physician wants clarity, control, and confidence. That's why we reimagine what's possible—designing and delivering minimally invasive medical devices that do more, with less. Seamlessly. Intuitively. Globally.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 sm:gap-4">
            <button className="bg-cook-red hover:bg-cook-dark-red text-medical-white px-6 sm:px-8 py-3 rounded-full font-manrope font-semibold transition-colors duration-200 shadow-lg text-sm sm:text-base">
              Explore Our Products
            </button>
            <button className="border-2 border-medical-white text-medical-white hover:bg-medical-white hover:text-graphite-gray px-6 sm:px-8 py-3 rounded-full font-manrope font-semibold transition-all duration-200 shadow-lg backdrop-blur-sm text-sm sm:text-base">
              Learn About Cook Medical
            </button>
          </div>
        </div>
      </div>

      {/* Statistics Card - Positioned in Bottom Right Corner, Hidden on Mobile */}
      <div className="absolute bottom-8 right-4 sm:bottom-12 sm:right-6 lg:bottom-16 lg:right-8 z-20 hidden sm:block">
        <StatisticsCard />
      </div>
    </section>
  );
};

export default HeroSection;
