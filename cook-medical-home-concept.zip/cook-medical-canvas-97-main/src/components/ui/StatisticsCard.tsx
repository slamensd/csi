
import React from 'react';
import { useAnimatedCounter } from '../../hooks/useAnimatedCounter';

const StatisticsCard = () => {
  const procedureCount = useAnimatedCounter({
    targetValue: 6384,
    increment: 1,
    intervalMs: 2500
  });

  return (
    <div className="backdrop-blur-lg bg-white/10 border border-white/20 rounded-xl p-4 sm:p-6 shadow-2xl">
      <div className="text-center">
        <div className="text-2xl sm:text-3xl lg:text-4xl font-manrope font-bold text-medical-white mb-1 sm:mb-2">
          {procedureCount.toLocaleString()}
        </div>
        <div className="text-sm sm:text-base font-dm-sans text-medical-white/90">
          procedures assisted today
        </div>
      </div>
    </div>
  );
};

export default StatisticsCard;
