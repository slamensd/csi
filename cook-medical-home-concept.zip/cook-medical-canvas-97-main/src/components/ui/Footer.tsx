
import React from 'react';
import { ExternalLink, Phone, Mail, MapPin, Facebook, Twitter, Linkedin, Youtube } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-graphite-gray text-medical-white">
      {/* Main Footer Content */}
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12">
          
          {/* Company Info & Logo - Left Column */}
          <div className="lg:col-span-4">
            <div className="mb-6">
              <img 
                src="https://vascularnews.com/wp-content/uploads/sites/7/2021/05/cookmedical_logo.jpg" 
                alt="Cook Medical Logo" 
                className="h-12 w-auto mb-4"
              />
              <p className="text-medical-white/80 font-dm-sans leading-relaxed mb-6">
                Cook Medical is a family-owned medical technology company that combines the skills and resources of a global enterprise with the values of a family business.
              </p>
            </div>
            
            {/* Contact Info */}
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <Phone className="h-4 w-4 text-cook-red" />
                <span className="text-sm font-dm-sans text-medical-white/80">1-800-457-4500</span>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="h-4 w-4 text-cook-red" />
                <span className="text-sm font-dm-sans text-medical-white/80">info@cookmedical.com</span>
              </div>
              <div className="flex items-start space-x-3">
                <MapPin className="h-4 w-4 text-cook-red mt-1" />
                <span className="text-sm font-dm-sans text-medical-white/80">
                  750 Daniels Way<br />
                  Bloomington, IN 47402
                </span>
              </div>
            </div>
          </div>

          {/* Navigation Links - Right Columns */}
          <div className="lg:col-span-8">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
              
              {/* Products & Solutions */}
              <div>
                <h3 className="text-lg font-manrope font-bold text-medical-white mb-4">Products & Solutions</h3>
                <ul className="space-y-3">
                  <li>
                    <a href="#" className="text-medical-white/80 hover:text-cook-red transition-colors duration-200 font-dm-sans text-sm">
                      Vascular
                    </a>
                  </li>
                  <li>
                    <a href="#" className="text-medical-white/80 hover:text-cook-red transition-colors duration-200 font-dm-sans text-sm">
                      MedSurg
                    </a>
                  </li>
                  <li>
                    <a href="#" className="text-medical-white/80 hover:text-cook-red transition-colors duration-200 font-dm-sans text-sm">
                      Interventional Radiology
                    </a>
                  </li>
                  <li>
                    <a href="#" className="text-medical-white/80 hover:text-cook-red transition-colors duration-200 font-dm-sans text-sm">
                      Critical Care
                    </a>
                  </li>
                  <li>
                    <a href="#" className="text-medical-white/80 hover:text-cook-red transition-colors duration-200 font-dm-sans text-sm">
                      Endoscopy
                    </a>
                  </li>
                </ul>
              </div>

              {/* Company */}
              <div>
                <h3 className="text-lg font-manrope font-bold text-medical-white mb-4">Company</h3>
                <ul className="space-y-3">
                  <li>
                    <a href="#" className="text-medical-white/80 hover:text-cook-red transition-colors duration-200 font-dm-sans text-sm">
                      About Us
                    </a>
                  </li>
                  <li>
                    <a href="#" className="text-medical-white/80 hover:text-cook-red transition-colors duration-200 font-dm-sans text-sm">
                      Leadership
                    </a>
                  </li>
                  <li>
                    <a href="#" className="text-medical-white/80 hover:text-cook-red transition-colors duration-200 font-dm-sans text-sm">
                      News & Events
                    </a>
                  </li>
                  <li>
                    <a href="#" className="text-medical-white/80 hover:text-cook-red transition-colors duration-200 font-dm-sans text-sm">
                      Careers
                    </a>
                  </li>
                  <li>
                    <a href="#" className="text-medical-white/80 hover:text-cook-red transition-colors duration-200 font-dm-sans text-sm">
                      Sustainability
                    </a>
                  </li>
                </ul>
              </div>

              {/* Support & Resources */}
              <div>
                <h3 className="text-lg font-manrope font-bold text-medical-white mb-4">Support & Resources</h3>
                <ul className="space-y-3">
                  <li>
                    <a href="#" className="text-medical-white/80 hover:text-cook-red transition-colors duration-200 font-dm-sans text-sm">
                      Customer Service
                    </a>
                  </li>
                  <li>
                    <a href="#" className="text-medical-white/80 hover:text-cook-red transition-colors duration-200 font-dm-sans text-sm">
                      Training & Education
                    </a>
                  </li>
                  <li>
                    <a href="#" className="text-medical-white/80 hover:text-cook-red transition-colors duration-200 font-dm-sans text-sm">
                      Clinical Resources
                    </a>
                  </li>
                  <li>
                    <a href="#" className="text-medical-white/80 hover:text-cook-red transition-colors duration-200 font-dm-sans text-sm">
                      Product Catalogs
                    </a>
                  </li>
                  <li>
                    <a href="#" className="text-medical-white/80 hover:text-cook-red transition-colors duration-200 font-dm-sans text-sm">
                      Contact Support
                    </a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Footer */}
      <div className="border-t border-medical-white/20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col lg:flex-row justify-between items-center space-y-4 lg:space-y-0">
            
            {/* Copyright & Legal Links */}
            <div className="flex flex-col sm:flex-row items-center space-y-2 sm:space-y-0 sm:space-x-6 text-center lg:text-left">
              <p className="text-sm font-dm-sans text-medical-white/70">
                © {currentYear} Cook Medical. All rights reserved.
              </p>
              <div className="flex items-center space-x-4">
                <a href="#" className="text-sm font-dm-sans text-medical-white/70 hover:text-cook-red transition-colors duration-200">
                  Privacy Policy
                </a>
                <span className="text-medical-white/40">|</span>
                <a href="#" className="text-sm font-dm-sans text-medical-white/70 hover:text-cook-red transition-colors duration-200">
                  Terms of Use
                </a>
                <span className="text-medical-white/40">|</span>
                <a href="#" className="text-sm font-dm-sans text-medical-white/70 hover:text-cook-red transition-colors duration-200">
                  Compliance
                </a>
              </div>
            </div>

            {/* Social Media Links */}
            <div className="flex items-center space-x-4">
              <a 
                href="#" 
                className="p-2 bg-medical-white/10 hover:bg-cook-red rounded-full transition-colors duration-200"
                aria-label="Facebook"
              >
                <Facebook className="h-4 w-4 text-medical-white" />
              </a>
              <a 
                href="#" 
                className="p-2 bg-medical-white/10 hover:bg-cook-red rounded-full transition-colors duration-200"
                aria-label="Twitter"
              >
                <Twitter className="h-4 w-4 text-medical-white" />
              </a>
              <a 
                href="#" 
                className="p-2 bg-medical-white/10 hover:bg-cook-red rounded-full transition-colors duration-200"
                aria-label="LinkedIn"
              >
                <Linkedin className="h-4 w-4 text-medical-white" />
              </a>
              <a 
                href="#" 
                className="p-2 bg-medical-white/10 hover:bg-cook-red rounded-full transition-colors duration-200"
                aria-label="YouTube"
              >
                <Youtube className="h-4 w-4 text-medical-white" />
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
