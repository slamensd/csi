
import React from 'react';
import { Button } from './button';
import { ArrowRight, DollarSign, Users, Leaf } from 'lucide-react';

const ImpactSection = () => {
  const statistics = [
    {
      icon: <DollarSign className="h-6 w-6 sm:h-8 sm:w-8" />,
      value: "$2.4B",
      label: "Annual supplier purchases"
    },
    {
      icon: <Users className="h-6 w-6 sm:h-8 sm:w-8" />,
      value: "15M+",
      label: "Procedures assisted annually"
    },
    {
      icon: <Leaf className="h-6 w-6 sm:h-8 sm:w-8" />,
      value: "Carbon",
      label: "Neutral by 2030"
    }
  ];

  return (
    <section className="py-12 sm:py-16 lg:py-20 bg-porcelain-gray">
      <div className="container mx-auto px-4 sm:px-6 lg:px-4">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 lg:gap-12">
          {/* Main Impact Content */}
          <div className="lg:col-span-2 space-y-8 sm:space-y-10 lg:space-y-12">
            {/* Header Content */}
            <div className="space-y-4 sm:space-y-6 text-center lg:text-left">
              <div className="text-xs sm:text-sm font-dm-sans text-soft-charcoal tracking-wider uppercase">
                [OUR IMPACT]
              </div>
              
              <h2 className="text-2xl sm:text-3xl lg:text-4xl font-manrope font-bold text-graphite-gray leading-tight">
                A healthy life. A healthy planet. For everyone.
              </h2>
              
              <p className="text-base sm:text-lg font-dm-sans text-soft-charcoal leading-relaxed max-w-2xl mx-auto lg:mx-0">
                Cook Medical's commitment extends beyond medical devices. We're building a sustainable future where innovative healthcare solutions protect both patients and our planet.
              </p>
              
              <div className="flex justify-center lg:justify-start">
                <Button className="bg-cook-red hover:bg-cook-dark-red text-medical-white font-manrope font-semibold rounded-full px-6 sm:px-8 py-3 transition-colors duration-200 flex items-center space-x-2">
                  <span>Learn more</span>
                  <ArrowRight className="h-4 w-4 sm:h-5 sm:w-5" />
                </Button>
              </div>
            </div>

            {/* Statistics Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-6">
              {statistics.map((stat, index) => (
                <div key={index} className="bg-medical-white border border-surgical-steel rounded-xl p-4 sm:p-6 text-center space-y-3 sm:space-y-4 shadow-sm">
                  <div className="flex justify-center text-cook-red">
                    {stat.icon}
                  </div>
                  <div className="text-xl sm:text-2xl font-manrope font-bold text-graphite-gray">
                    {stat.value}
                  </div>
                  <div className="text-xs sm:text-sm font-dm-sans text-soft-charcoal leading-relaxed">
                    {stat.label}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Sidebar Card */}
          <div className="lg:col-span-1 mt-8 lg:mt-0">
            <div className="bg-medical-white border border-surgical-steel rounded-xl overflow-hidden h-full flex flex-col shadow-sm">
              {/* Image */}
              <div className="aspect-[4/3] overflow-hidden">
                <img 
                  src="https://images.unsplash.com/photo-1605810230434-7631ac76ec81?w=800&h=600&fit=crop"
                  alt="Healthcare professionals and patients"
                  className="w-full h-full object-cover"
                />
              </div>
              
              {/* Content */}
              <div className="p-4 sm:p-6 lg:p-8 flex flex-col flex-grow space-y-4 sm:space-y-6">
                <div className="text-xs sm:text-sm font-dm-sans text-cook-red tracking-wider uppercase">
                  [IMPACT REPORTING]
                </div>
                
                <h3 className="text-lg sm:text-xl font-manrope font-bold text-graphite-gray leading-tight">
                  Real patient stories. Real impact.
                </h3>
                
                <p className="text-soft-charcoal font-dm-sans leading-relaxed flex-grow text-sm sm:text-base">
                  Discover how Cook Medical devices are advancing healthcare outcomes and transforming lives around the world.
                </p>
                
                <Button className="bg-cook-red hover:bg-cook-dark-red text-medical-white font-manrope font-semibold rounded-full transition-colors duration-200 flex items-center justify-center space-x-2 w-full">
                  <span>Read how</span>
                  <ArrowRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ImpactSection;
