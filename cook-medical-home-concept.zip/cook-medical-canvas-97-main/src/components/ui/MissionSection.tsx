
import React from 'react';

const MissionSection = () => {
  return (
    <section className="min-h-screen bg-medical-white flex items-center py-12 sm:py-16 lg:py-0">
      <div className="container mx-auto px-4 sm:px-6 lg:px-4">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 sm:gap-8 lg:gap-12 items-center mb-4 sm:mb-8">
          {/* Left Column - Label */}
          <div className="lg:col-span-1 text-center lg:text-left">
            <div className="text-xs sm:text-sm font-dm-sans text-soft-charcoal tracking-wider uppercase">
              [OUR MISSION]
            </div>
          </div>

          {/* Right Column - Main Content */}
          <div className="lg:col-span-2 text-center lg:text-left">
            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-manrope font-bold text-graphite-gray mb-4 sm:mb-6 lg:mb-8 leading-tight">
              We simplify the complex. At Cook Medical, we design minimally invasive devices that empower physicians and restore lives—with precision, purpose, and compassion.
            </h2>
            
            <p className="text-sm sm:text-base font-dm-sans text-soft-charcoal leading-relaxed max-w-4xl mx-auto lg:mx-0">
              Every product we create is built around a simple truth: better tools lead to better outcomes. From the operating room to recovery, we help healthcare teams do more with less—reducing trauma, accelerating healing, and making the extraordinary feel effortless.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default MissionSection;
