import React from 'react';
import { Button } from './button';

const ProductCards = () => {
  const cards = [
    {
      id: 1,
      title: 'Instructions for Use Finder',
      description: 'Locate the product IFU you need',
      image: 'https://images.unsplash.com/photo-1518770660439-4636190af475?w=800&h=600&fit=crop',
      buttonText: 'Locate IFU'
    },
    {
      id: 2,
      title: 'Customer Portal',
      description: 'Your account information and helpful tools in one central place',
      image: 'https://images.unsplash.com/photo-1531297484001-80022131f5a1?w=800&h=600&fit=crop',
      buttonText: 'Access Portal'
    },
    {
      id: 3,
      title: 'Vista® Education & Training',
      description: 'Find education and training events for Cook products',
      image: 'https://images.unsplash.com/photo-1605810230434-7631ac76ec81?w=800&h=600&fit=crop',
      buttonText: 'Browse Courses'
    }
  ];

  return (
    <section className="py-20 bg-surgical-steel">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {cards.map((card) => (
            <div 
              key={card.id}
              className="bg-porcelain-gray rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300 group flex flex-col"
            >
              {/* Full Bleed Image */}
              <div className="aspect-[4/3] overflow-hidden">
                <img 
                  src={card.image}
                  alt={card.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
              </div>
              
              {/* Card Content */}
              <div className="p-6 flex flex-col flex-grow">
                <h3 className="text-lg font-manrope font-bold text-graphite-gray mb-3">
                  {card.title}
                </h3>
                <p className="text-soft-charcoal font-dm-sans mb-6 leading-relaxed flex-grow">
                  {card.description}
                </p>
                <Button 
                  className="w-full bg-cook-red hover:bg-cook-dark-red text-medical-white font-manrope font-semibold rounded-full transition-colors duration-200 mt-auto"
                >
                  {card.buttonText}
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ProductCards;
