
import React from 'react';
import { Button } from './button';
import { ArrowRight, ExternalLink } from 'lucide-react';

const CareersSection = () => {
  const jobCategories = [
    {
      title: 'Sales jobs',
      description: 'Drive growth and build relationships with healthcare professionals',
      count: '12 open positions'
    },
    {
      title: 'Engineering jobs', 
      description: 'Design and develop innovative medical devices that save lives',
      count: '8 open positions'
    },
    {
      title: 'IT jobs',
      description: 'Build technology solutions that support our mission',
      count: '5 open positions'
    }
  ];

  return (
    <section className="relative min-h-screen bg-graphite-gray overflow-hidden">
      {/* Full Bleed Video Background */}
      <div className="absolute inset-0 w-full h-full">
        <video 
          className="w-full h-full object-cover"
          autoPlay 
          muted 
          loop 
          playsInline
        >
          <source src="https://meetnippy.mypinata.cloud/ipfs/bafybeifu7tn3yc5givn6ldpxloxdg5lu6ky3ufqkwitd3ksu32np6qqtqu" type="video/mp4" />
        </video>
        {/* Dark overlay for text readability */}
        <div className="absolute inset-0 bg-black/60"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 sm:px-6 lg:px-4 py-12 sm:py-16 lg:py-20">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 sm:gap-8 min-h-[80vh]">
          {/* Main Content - Left Side */}
          <div className="lg:col-span-8 flex flex-col justify-center text-center lg:text-left">
            <div className="text-xs sm:text-sm font-dm-sans text-medical-white/80 tracking-wider uppercase mb-4 sm:mb-6">
              [CAREERS]
            </div>
            
            <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-manrope font-bold text-medical-white mb-6 sm:mb-8 leading-tight">
              Careers that change lives
            </h1>
            
            <p className="text-base sm:text-lg lg:text-xl font-dm-sans text-medical-white/90 leading-relaxed mb-8 sm:mb-12 max-w-2xl mx-auto lg:mx-0">
              Join a team where your work has meaning. At Cook Medical, every role contributes to our mission of improving lives through innovative medical technology. Build a career that makes a difference.
            </p>
            
            <div className="flex justify-center lg:justify-start">
              <Button className="bg-cook-red hover:bg-cook-dark-red text-medical-white px-6 sm:px-8 py-3 sm:py-4 rounded-full font-manrope font-semibold transition-colors duration-200 flex items-center space-x-2 sm:space-x-3 text-base sm:text-lg w-fit">
                <span>Join the team</span>
                <ArrowRight className="h-5 w-5 sm:h-6 sm:w-6" />
              </Button>
            </div>
          </div>

          {/* Right Sidebar */}
          <div className="lg:col-span-4 flex flex-col justify-center mt-8 lg:mt-0">
            <div className="bg-medical-white/10 backdrop-blur-md border border-medical-white/20 rounded-xl p-4 sm:p-6 lg:p-8 space-y-4 sm:space-y-6">
              <div className="space-y-3 sm:space-y-4">
                <a 
                  href="#" 
                  className="flex items-center justify-between p-3 sm:p-4 bg-medical-white/5 hover:bg-medical-white/10 border border-medical-white/20 rounded-lg transition-colors duration-200 group"
                >
                  <span className="font-dm-sans text-medical-white font-medium text-sm sm:text-base">Explore our Careers site</span>
                  <ExternalLink className="h-4 w-4 sm:h-5 sm:w-5 text-medical-white/70 group-hover:text-medical-white transition-colors duration-200" />
                </a>
                
                <a 
                  href="#" 
                  className="flex items-center justify-between p-3 sm:p-4 bg-medical-white/5 hover:bg-medical-white/10 border border-medical-white/20 rounded-lg transition-colors duration-200 group"
                >
                  <span className="font-dm-sans text-medical-white font-medium text-sm sm:text-base">Join our Talent Network</span>
                  <ExternalLink className="h-4 w-4 sm:h-5 sm:w-5 text-medical-white/70 group-hover:text-medical-white transition-colors duration-200" />
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* Job Categories - Bottom Section */}
        <div className="mt-12 sm:mt-16 lg:mt-20">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
            {jobCategories.map((category, index) => (
              <div 
                key={index}
                className="bg-medical-white/10 backdrop-blur-md border border-medical-white/20 rounded-xl p-4 sm:p-6 hover:bg-medical-white/15 transition-colors duration-300 group cursor-pointer"
              >
                <h3 className="text-lg sm:text-xl font-manrope font-bold text-medical-white mb-2 sm:mb-3 group-hover:text-cook-red transition-colors duration-200">
                  {category.title}
                </h3>
                <p className="text-medical-white/80 font-dm-sans mb-3 sm:mb-4 leading-relaxed text-sm sm:text-base">
                  {category.description}
                </p>
                <div className="flex items-center justify-between">
                  <span className="text-xs sm:text-sm font-dm-sans text-medical-white/70">
                    {category.count}
                  </span>
                  <ArrowRight className="h-4 w-4 sm:h-5 sm:w-5 text-medical-white/70 group-hover:text-cook-red group-hover:translate-x-1 transition-all duration-200" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default CareersSection;
