
import React from 'react';
import { Button } from './button';

const DivisionCards = () => {
  const cards = [
    {
      eyebrow: 'Product',
      title: 'Thoracic Portfolio',
      link: 'View Details'
    },
    {
      eyebrow: 'Product',
      title: 'Abdominal Portfolio',
      link: 'View Details'
    },
    {
      eyebrow: 'Solutions',
      title: 'MyAortic Case Support',
      link: 'Learn More'
    },
    {
      eyebrow: 'Insight',
      title: 'Learn about our legacy of durability',
      link: 'Read More'
    },
    {
      eyebrow: 'Accessories',
      title: 'Zenith endovascular accessories',
      link: 'Explore'
    },
    {
      eyebrow: 'Product',
      title: 'European Union Catalog',
      link: 'View Catalog'
    }
  ];

  const handleCardClick = (title: string) => {
    console.log(`Clicked on: ${title}`);
    // Future expansion point for navigation
  };

  return (
    <div className="space-y-8 animate-fade-in">
      {/* 3x2 Grid of Cards - Wider and Centered */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
        {cards.map((card, index) => (
          <div
            key={index}
            className="bg-white/95 backdrop-blur-sm rounded-xl p-8 shadow-xl border border-white/30 hover:bg-white hover:shadow-2xl transition-all duration-500 group cursor-pointer transform hover:scale-105"
            style={{
              animationDelay: `${index * 100}ms`
            }}
            onClick={() => handleCardClick(card.title)}
          >
            <div className="space-y-4">
              <div className="text-sm font-manrope font-bold text-cook-red uppercase tracking-wider">
                {card.eyebrow}
              </div>
              <h3 className="text-xl font-manrope font-bold text-graphite-gray group-hover:text-cook-red transition-colors duration-300 leading-tight">
                {card.title}
              </h3>
              <div className="text-sm font-dm-sans text-soft-charcoal opacity-80">
                {card.link}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* CTA Button */}
      <div className="flex justify-center pt-4">
        <Button
          onClick={() => console.log('Contact action')}
          className="bg-cook-red hover:bg-cook-dark-red text-medical-white px-12 py-5 rounded-full font-manrope font-bold text-xl transition-all duration-300 hover:shadow-xl transform hover:scale-105"
        >
          Get in Touch
        </Button>
      </div>
    </div>
  );
};

export default DivisionCards;
