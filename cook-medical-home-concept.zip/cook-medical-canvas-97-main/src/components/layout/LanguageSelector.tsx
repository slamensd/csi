
import React, { useState, useRef, useEffect } from 'react';
import { ChevronDown, Globe } from 'lucide-react';

interface LanguageSelectorProps {
  languages: string[];
  variant?: 'header' | 'menu';
  align?: 'start' | 'center' | 'end';
}

const LanguageSelector = ({ languages, variant = 'header', align = 'end' }: LanguageSelectorProps) => {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const isMenuVariant = variant === 'menu';
  
  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const getAlignmentClass = () => {
    switch (align) {
      case 'start': return 'left-0';
      case 'center': return 'left-1/2 transform -translate-x-1/2';
      case 'end': return 'right-0';
      default: return 'right-0';
    }
  };
  
  return (
    <div className="relative" ref={dropdownRef}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={`flex items-center space-x-2 text-medical-white hover:text-cook-red transition-colors duration-200 focus:outline-none bg-white/10 backdrop-blur-sm rounded-full px-4 border border-white/20 hover:bg-white/20 ${
          isMenuVariant ? 'py-3 w-full justify-center' : 'py-2 drop-shadow-md'
        }`}
      >
        <Globe className="h-5 w-5" />
        {isMenuVariant && <span className="font-dm-sans">Select Region</span>}
        <ChevronDown className={`h-4 w-4 transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
      </button>
      
      {isOpen && (
        <div 
          className={`absolute top-full mt-2 bg-white border border-surgical-steel shadow-xl rounded-lg z-50 min-w-[200px] backdrop-blur-sm ${getAlignmentClass()}`}
        >
          <div className="py-2">
            {languages.map((language) => (
              <button
                key={language}
                onClick={() => {
                  setIsOpen(false);
                  // Handle language selection here
                  console.log('Selected language:', language);
                }}
                className="w-full text-left text-graphite-gray font-dm-sans hover:bg-porcelain-gray hover:text-cook-red cursor-pointer px-4 py-3 transition-colors duration-200"
              >
                {language}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default LanguageSelector;
