
import React from 'react';
import { X } from 'lucide-react';
import { SheetClose } from '@/components/ui/sheet';
import LanguageSelector from './LanguageSelector';

interface DesktopMenuContentProps {
  title: string;
  menuItems: string[];
  languages: string[];
  onClose: () => void;
}

const DesktopMenuContent = ({ title, menuItems, languages, onClose }: DesktopMenuContentProps) => {
  return (
    <div className="flex flex-col h-full">
      {/* Desktop Menu Header */}
      <div className="flex items-center justify-between p-6 border-b border-white/10">
        <img 
          src="https://vascularnews.com/wp-content/uploads/sites/7/2021/05/cookmedical_logo.jpg" 
          alt="Cook Medical" 
          className="h-10 w-auto object-contain"
        />
        <SheetClose asChild>
          <button className="text-medical-white hover:text-cook-red transition-colors duration-200 p-2">
            <X className="h-6 w-6" />
          </button>
        </SheetClose>
      </div>

      {/* Desktop Menu Content */}
      <div className="flex-1 px-6 py-8">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-manrope font-bold text-medical-white mb-8">{title}</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {menuItems.map((subItem) => (
              <a
                key={subItem}
                href="#"
                className="block text-xl font-manrope text-medical-white hover:text-cook-red transition-colors duration-200 py-3 border-b border-white/20 hover:border-cook-red/50"
                onClick={onClose}
              >
                {subItem}
              </a>
            ))}
          </div>
        </div>
      </div>

      {/* Desktop Menu Footer */}
      <div className="p-6 border-t border-white/10 space-y-4">
        <div className="max-w-6xl mx-auto flex flex-col items-center space-y-4">
          <button 
            className="bg-cook-red hover:bg-cook-dark-red text-medical-white px-12 py-4 rounded-full font-manrope font-semibold transition-colors duration-200 shadow-lg text-lg"
            onClick={onClose}
          >
            Get in Touch
          </button>
          
          <LanguageSelector languages={languages} variant="menu" align="center" />
        </div>
      </div>
    </div>
  );
};

export default DesktopMenuContent;
