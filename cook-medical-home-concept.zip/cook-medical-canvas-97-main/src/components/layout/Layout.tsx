
import React from 'react';
import Header from './Header';
import Footer from '../ui/Footer';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout = ({ children }: LayoutProps) => {
  return (
    <div className="min-h-screen bg-medical-white">
      {/* Header positioned as overlay */}
      <Header />
      
      {/* Main content starts from top, header will overlay it */}
      <main className="relative">
        {children}
      </main>

      {/* Footer */}
      <Footer />
    </div>
  );
};

export default Layout;
