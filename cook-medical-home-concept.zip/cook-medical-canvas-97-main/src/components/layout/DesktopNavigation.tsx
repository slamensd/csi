
import React from 'react';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import DesktopMenuContent from './DesktopMenuContent';
import LanguageSelector from './LanguageSelector';

interface DesktopNavigationProps {
  navigationItems: string[];
  menuContent: Record<string, string[]>;
  languages: string[];
  activeDesktopMenu: string | null;
  onMenuOpen: (item: string) => void;
  onMenuClose: () => void;
}

const DesktopNavigation = ({ 
  navigationItems, 
  menuContent, 
  languages, 
  activeDesktopMenu, 
  onMenuOpen, 
  onMenuClose 
}: DesktopNavigationProps) => {
  return (
    <>
      {/* Desktop Navigation */}
      <nav className="hidden md:flex items-center space-x-8">
        {navigationItems.map((item) => (
          <Sheet key={item} open={activeDesktopMenu === item} onOpenChange={(open) => open ? onMenuOpen(item) : onMenuClose()}>
            <SheetTrigger asChild>
              <button className="text-medical-white font-manrope font-semibold hover:text-cook-red transition-colors duration-200 drop-shadow-md">
                {item}
              </button>
            </SheetTrigger>
            <SheetContent 
              side="top" 
              className="w-full h-full bg-graphite-gray border-none p-0 z-50 [&>button]:hidden"
            >
              <DesktopMenuContent
                title={item}
                menuItems={menuContent[item as keyof typeof menuContent]}
                languages={languages}
                onClose={onMenuClose}
              />
            </SheetContent>
          </Sheet>
        ))}
      </nav>
      
      {/* Desktop CTA Button and Language Selector */}
      <div className="hidden md:flex items-center space-x-4">
        <button className="bg-cook-red hover:bg-cook-dark-red text-medical-white px-8 py-3 rounded-full font-manrope font-semibold transition-colors duration-200 shadow-lg">
          Get in Touch
        </button>
        
        <LanguageSelector languages={languages} />
      </div>
    </>
  );
};

export default DesktopNavigation;
