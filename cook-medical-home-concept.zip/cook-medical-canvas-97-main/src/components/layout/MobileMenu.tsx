
import React from 'react';
import { Menu, X } from 'lucide-react';
import { Sheet, SheetClose, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import LanguageSelector from './LanguageSelector';

interface MobileMenuProps {
  navigationItems: string[];
  languages: string[];
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
}

const MobileMenu = ({ navigationItems, languages, isOpen, onOpenChange }: MobileMenuProps) => {
  return (
    <div className="md:hidden">
      <Sheet open={isOpen} onOpenChange={onOpenChange}>
        <SheetTrigger asChild>
          <button className="text-medical-white hover:text-cook-red transition-colors duration-200 p-2">
            <Menu className="h-6 w-6" />
          </button>
        </SheetTrigger>
        <SheetContent 
          side="top" 
          className="w-full h-full bg-graphite-gray border-none p-0 z-50 [&>button]:hidden"
        >
          <div className="flex flex-col h-full">
            {/* Mobile Header */}
            <div className="flex items-center justify-between p-6 border-b border-white/10">
              <img 
                src="https://vascularnews.com/wp-content/uploads/sites/7/2021/05/cookmedical_logo.jpg" 
                alt="Cook Medical" 
                className="h-10 w-auto object-contain"
              />
              <SheetClose asChild>
                <button className="text-medical-white hover:text-cook-red transition-colors duration-200 p-2">
                  <X className="h-6 w-6" />
                </button>
              </SheetClose>
            </div>

            {/* Mobile Navigation */}
            <nav className="flex-1 px-6 py-8">
              <div className="space-y-8">
                {navigationItems.map((item) => (
                  <a
                    key={item}
                    href="#"
                    className="block text-2xl font-manrope font-semibold text-medical-white hover:text-cook-red transition-colors duration-200"
                    onClick={() => onOpenChange(false)}
                  >
                    {item}
                  </a>
                ))}
              </div>
            </nav>

            {/* Mobile Footer */}
            <div className="p-6 border-t border-white/10 space-y-4">
              <button 
                className="w-full bg-cook-red hover:bg-cook-dark-red text-medical-white px-8 py-4 rounded-full font-manrope font-semibold transition-colors duration-200 shadow-lg text-lg"
                onClick={() => onOpenChange(false)}
              >
                Get in Touch
              </button>
              
              <LanguageSelector languages={languages} variant="menu" align="center" />
            </div>
          </div>
        </SheetContent>
      </Sheet>
    </div>
  );
};

export default MobileMenu;
