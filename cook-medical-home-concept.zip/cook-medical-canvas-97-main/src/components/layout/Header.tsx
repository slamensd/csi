
import React, { useState } from 'react';
import { useLocation, Link } from 'react-router-dom';
import DesktopNavigation from './DesktopNavigation';
import MobileMenu from './MobileMenu';

const Header = () => {
  const location = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [activeDesktopMenu, setActiveDesktopMenu] = useState<string | null>(null);
  
  // Check if we're on an inner page (not the homepage)
  const isInnerPage = location.pathname !== '/';
  
  const languages = [
    'Asia-Pacific',
    'Australia',
    'China',
    'Europe',
    'India',
    'Japan',
    'South Korea'
  ];

  const navigationItems = [
    'For Patients & Caregivers',
    'For Healthcare Professionals',
    'Our Company'
  ];

  const menuContent = {
    'For Patients & Caregivers': [
      'Patient Resources',
      'Medical Conditions',
      'Treatment Options',
      'Support & Care',
      'Educational Materials',
      'Find a Doctor'
    ],
    'For Healthcare Professionals': [
      'Medical Devices',
      'Clinical Training',
      'Research & Studies',
      'Technical Support',
      'Product Catalog',
      'Professional Resources'
    ],
    'Our Company': [
      'About Cook Medical',
      'Leadership Team',
      'Careers',
      'News & Events',
      'Investor Relations',
      'Contact Us'
    ]
  };

  const handleDesktopMenuOpen = (item: string) => {
    setActiveDesktopMenu(item);
  };

  const handleDesktopMenuClose = () => {
    setActiveDesktopMenu(null);
  };

  return (
    <header className={`absolute top-0 left-0 right-0 z-30 ${
      isInnerPage 
        ? 'bg-graphite-gray' 
        : 'bg-transparent backdrop-blur-sm bg-black/10'
    }`}>
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo Section */}
          <div className="flex items-center">
            <Link to="/">
              <img 
                src="https://vascularnews.com/wp-content/uploads/sites/7/2021/05/cookmedical_logo.jpg" 
                alt="Cook Medical" 
                className="h-10 sm:h-12 w-auto object-contain drop-shadow-lg hover:opacity-80 transition-opacity duration-200"
              />
            </Link>
          </div>
          
          <DesktopNavigation
            navigationItems={navigationItems}
            menuContent={menuContent}
            languages={languages}
            activeDesktopMenu={activeDesktopMenu}
            onMenuOpen={handleDesktopMenuOpen}
            onMenuClose={handleDesktopMenuClose}
          />

          <MobileMenu
            navigationItems={navigationItems}
            languages={languages}
            isOpen={isMobileMenuOpen}
            onOpenChange={setIsMobileMenuOpen}
          />
        </div>
      </div>
    </header>
  );
};

export default Header;
