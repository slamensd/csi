
import React from 'react';
import Layout from '../components/layout/Layout';
import HeroSection from '../components/ui/HeroSection';
import MissionSection from '../components/ui/MissionSection';
import SearchSection from '../components/ui/SearchSection';
import ImpactSection from '../components/ui/ImpactSection';
import CareersSection from '../components/ui/CareersSection';

const Index = () => {
  return (
    <Layout>
      <HeroSection />
      <MissionSection />
      <SearchSection />
      <ImpactSection />
      <CareersSection />
    </Layout>
  );
};

export default Index;
