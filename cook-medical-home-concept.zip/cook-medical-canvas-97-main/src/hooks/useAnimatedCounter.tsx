import { useState, useEffect } from 'react';

interface UseAnimatedCounterProps {
  targetValue: number;
  increment: number;
  intervalMs: number;
}

export const useAnimatedCounter = ({ targetValue, increment, intervalMs }: UseAnimatedCounterProps) => {
  const [currentValue, setCurrentValue] = useState(targetValue - 100); // Start a bit below target

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentValue(prev => {
        const newValue = prev + increment;
        // Keep incrementing past target to create continuous counting effect
        return newValue;
      });
    }, intervalMs);

    return () => clearInterval(interval);
  }, [increment, intervalMs]);

  return currentValue;
};
